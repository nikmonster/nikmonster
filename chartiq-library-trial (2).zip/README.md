If you would like to use ChartIQ as a node package, please use the accompanying tarball and install directly with npm.
	- For help installing please see https://documentation.chartiq.com/tutorial-Installing%20with%20npm.html
	- This package is designed for versions 7.2.0 and above. Usage with earlier versions may require additional configuration.
If you would like to use ChartIQ with script tags or outside of NPM, please use the chartiq folder and see its contents.
	- A description of the folders and files can be found at: https://documentation.chartiq.com/tutorial-file-by-file-descriptions.html

If you are new to using ChartIQ's library we recommend that you visit the quick start guide at: https://documentation.chartiq.com/tutorial-Quick%20Start.html
Full documentation can be found at https://documentation.chartiq.com
